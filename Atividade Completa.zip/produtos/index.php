<?php

include 'config.php';

$sql = "SELECT * FROM produtos";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="styles.css">
    <title>Controle de Sistema</title>
</head>

<body>
    <!--Cabeçalho-->
    <header>
        <h1>Sistema de Estoque de Produtos</h1>
    </header>
    <nav>
        <a href="add_product.php">Cadastrar Produto</a>
        <a href="index.php">Voltar</a>
    </nav>
    <!--Conteudo-->
    <main>
        <h2>Lista de Produtos</h2>
        <table>
            <tr>
                <!--Cabeçalho das colunas da tabela-->

                <th>ID</th>
                <th>Produto</th>
                <th>Fabricante</th>
                <th>Valor</th>
                <th>Quantidade</th>
                <th>Descrição</th>
                <th>Ações</th>
            </tr>
<?php

if($result->num_rows>0) {
    while($row = $result->fetch_assoc()) {

        echo"<tr>
            <td>{$row['id']}</td>
            <td>{$row['produto']}</td>
            <td>{$row['fabricante']}</td>
            <td>{$row['valor']}</td>
            <td>{$row['quantidade']}</td>
            <td>{$row['descricao']}</td>
            <td>
                <a href='edit_product.php?id={$row['id']}'>Editar</a>

                <a href='delete_product.php?id={$row['id']}'>Excluir</a>
            </td>
        </tr>";
} 
}
else {
    echo "<tr><td colspan='7'>Nenhum produto encontrado</td></tr>";
}
?>
        </table>
    </main>
    <footer>
        <p>&copy;2024 Sistema de Estoque de Produtods. Todos os direitos reservados.</p>
    </footer>
</body>

</html>

<?php $conn->close(); ?>