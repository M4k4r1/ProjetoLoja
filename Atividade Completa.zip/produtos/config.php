<?php

$servername="localhost";

$username= "root";

$password= "";

$dbname= "produto_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if($conn->connect_error) {
    die("Connect failed:". $conn->connect_error);
}
else{
    echo "Conexão com banco de dados com sucesso!";
}
?>